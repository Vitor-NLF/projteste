from Pessoaa import *


lucas = Aluno(12,"Lucas",16)
lucas.caculo_media()
lucas.estudadar()

pedro = Professor(12,"Pedro",34,"Mestrado","Matemática",24,1400)
pedro.lecionar()