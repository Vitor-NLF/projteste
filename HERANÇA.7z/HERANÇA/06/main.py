from Funcionario import *


marcelo = Gerente("Marcelo",1212,24000,4444)
marcelo.compras()

luiz = Vendedor("luiz",4446,7800,1000)
luiz.bater_meta(222222,2000)