from Pessoa2 import *

pessoa_fisica = PessoaFisica("Vitor",9999999,"fnonvo@novn","Av Mato Grosso",44444)
pessoa_fisica.negociar()
pessoa_fisica.comprar()

pessoa_juridica = PessoaJuridica("Marcos",434434,"fvninv@fofvn","Afonso",323232323)
pessoa_juridica.negociar()
pessoa_juridica.vender()

