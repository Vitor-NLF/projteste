from Passagem import PassagemBus, PassagemAviao

pessoa1 = PassagemBus(32, 12, 5555, 43)
pessoa1.abastecer()

pessoa2 = PassagemAviao(100,12,40,1212)
pessoa2.decolar()