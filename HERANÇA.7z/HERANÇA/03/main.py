from Ingresso import *

joao = IngressoVip(543,678678,False, False,True, True)
joao.AcessarCamarote()
joao.PegarBebida()